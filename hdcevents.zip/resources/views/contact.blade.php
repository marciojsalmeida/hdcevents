@extends('layouts.main')

@section('title', 'Contatos do site')


@section('content')
<h1>Pagina de contatos</h1>
<a href="/">voltar para home</a>
@endsection


<?php $__env->startSection('title', 'Contatos do site'); ?>


<?php $__env->startSection('content'); ?>
<h1>Pagina de contatos</h1>
<a href="/">voltar para home</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Cursos\laravel\hdcevents\resources\views/contact.blade.php ENDPATH**/ ?>